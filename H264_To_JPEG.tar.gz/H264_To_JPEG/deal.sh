# 一般数据采集完后，都是这样的形式
# ├── 0907_178_data
# │   ├── navigation
# │   │   ├── camera
# │   │   ├── imu.txt
# |   |   ├── lidar
# │   │   ├── wheel
# │   └── spin
# │       ├── camera
# │       ├── imu.simu
# │       ├── lidar
# │       └── wheel

# 将解码工具解压放到 0907_178_data 下，执行此脚本，就会将所有数据进行解码

#./demo  ../navigation/camera/front_far/*.h264       ../navigation/camera/front_far        3840  2160   &&  sleep 1
#./demo  ../navigation/camera/front_wide/*.h264      ../navigation/camera/front_wide       3840  2160   &&  sleep 1
#./demo  ../navigation/camera/front_fisheye/*.h264   ../navigation/camera/front_fisheye    1280  960    &&  sleep 1
#./demo  ../navigation/camera/rear_fisheye/*.h264    ../navigation/camera/rear_fisheye     1280  960    &&  sleep 1
#./demo  ../navigation/camera/left_fisheye/*.h264    ../navigation/camera/left_fisheye     1280  960    &&  sleep 1
#./demo  ../navigation/camera/right_fisheye/*.h264   ../navigation/camera/right_fisheye    1280  960    &&  sleep 1
#./demo  ../navigation/camera/left_front/*.h264      ../navigation/camera/left_front       1936  1216   &&  sleep 1
#./demo  ../navigation/camera/left_rear/*.h264       ../navigation/camera/left_rear        1936  1216   &&  sleep 1
#./demo  ../navigation/camera/right_front/*.h264     ../navigation/camera/right_front      1936  1216   &&  sleep 1
#./demo  ../navigation/camera/right_rear/*.h264      ../navigation/camera/right_rear       1936  1216   &&  sleep 1
#./demo  ../navigation/camera/rear_mid/*.h264        ../navigation/camera/rear_mid         1936  1216   &&  sleep 1


./demo  ../motionless/camera/front_far/*.h264             ../motionless/camera/front_far              3840  2160   &&  sleep 1
./demo  ../motionless/camera/front_wide/*.h264            ../motionless/camera/front_wide             3840  2160   &&  sleep 1
./demo  ../motionless/camera/front_fisheye/*.h264         ../motionless/camera/front_fisheye          1280  960    &&  sleep 1
./demo  ../motionless/camera/rear_fisheye/*.h264          ../motionless/camera/rear_fisheye           1280  960    &&  sleep 1
./demo  ../motionless/camera/left_fisheye/*.h264          ../motionless/camera/left_fisheye           1280  960    &&  sleep 1
./demo  ../motionless/camera/right_fisheye/*.h264         ../motionless/camera/right_fisheye          1280  960    &&  sleep 1
./demo  ../motionless/camera/left_front/*.h264            ../motionless/camera/left_front             1936  1216   &&  sleep 1
./demo  ../motionless/camera/left_rear/*.h264             ../motionless/camera/left_rear              1936  1216   &&  sleep 1
./demo  ../motionless/camera/right_front/*.h264           ../motionless/camera/right_front            1936  1216   &&  sleep 1
./demo  ../motionless/camera/right_rear/*.h264            ../motionless/camera/right_rear             1936  1216   &&  sleep 1
./demo  ../motionless/camera/rear_mid/*.h264              ../motionless/camera/rear_mid               1936  1216   &&  sleep 1
